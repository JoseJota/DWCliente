
window.onload= function(){
	
		
	function muestraGaleria(e){
				
		}
		
	function muestraClasificacion(e){
		
		}
	
	function pasafotos(){
		
		}

	function actualizaListaGanadores(){
		
		var ganadores = new Array(
				new Array (new Array ("10K-Junior1","10K-Junior2","10K-Junior3"), new Array("10K-Senior1","10K-Senior2","10K-Senior3"),new Array("10K-Veteranos1","10K-Veteranos2","10K-Veteranos3")),
				new Array (new Array ("M-Junior1","M-Junior2","M-Junior3"), new Array("M-Senior1","M-Senior2","M-Senior3"),new Array("M-Veteranos1","M-Veteranos2","M-Veteranos3"))
				);
		
		
		}
	
	
}
